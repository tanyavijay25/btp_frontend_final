import React, { Component } from 'react'
import "../../footer.css"

class FooterComponent extends Component {
    render() {
        return (
            <footer className=" footerrr bg-dark">
                <span className="text-muted">All Rights Reserved by btp</span>
            </footer>
        )
    }
}

export default FooterComponent